import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:livq/controllers/noti_controller.dart';
import 'package:livq/screens/channels/channel_list.dart';
import 'package:livq/screens/root.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:livq/theme/colors.dart';
import 'controllerBindings.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:get/get.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

Future<void> _backMessage(RemoteMessage message) async {
  await Firebase.initializeApp();
  print('background message ${message.notification}');
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  FirebaseMessaging.onBackgroundMessage(_backMessage);
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final NotiController c = Get.put(NotiController());

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
        designSize: Size(376, 812),
        builder: () => GetMaterialApp(
          initialBinding: ControllerBindings(),
          debugShowCheckedModeBanner: false,
          home: AnimatedSplashScreen(
            splash: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset("assets/LiveQ_logo.gif"),
                SvgPicture.asset(
                  "assets/splash_text.svg",
                  color: AppColors.primaryColor,
                  height: 30.h,
                  // width: 5.w,
                ),
              ],
            ),
            splashIconSize: 360.0,
            backgroundColor: Color(0xffFFFDE7),
            nextScreen: FutureBuilder(
                future: c.initialize(),
                builder: (context, AsyncSnapshot snapshot) {
                  return Root();
                }),
          ),
        ));
  }
}
