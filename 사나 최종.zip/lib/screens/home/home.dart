import 'package:agora_rtc_engine/rtc_engine.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:livq/config.dart';
import 'package:livq/controllers/auth_controller.dart';
import 'package:livq/push_notification/push_notification.dart';
import 'package:livq/screens/channels/channel_list.dart';
import 'package:livq/screens/home/agora/pages/call_taker.dart';
import 'package:livq/screens/home/buttons/animated_radial_menu.dart';
import 'package:livq/screens/home/guide_page.dart';
import 'package:livq/screens/home/sub_category.dart';
import 'package:livq/screens/navigation_bar.dart';
import 'package:livq/screens/root.dart';
import 'package:livq/screens/sign_in/sign_in.dart';
import 'package:livq/theme/colors.dart';
import 'package:livq/widgets/rounded_text_formfield.dart';
import 'package:permission_handler/permission_handler.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool pressed1 = false;
  bool pressed2 = false;
  bool pressed3 = false;
  bool pressed4 = false;
  bool pressed5 = false;
  final List<String> _titleList = ['대중 교통', '애완 동물', '공부', '밥', '운동', ''];
  final List<String> _textList = [
    '에 대한 도움이 필요하시군요 !\n필요한 도움을 자세히 알려주시면\n 더 정확한 도움을 드릴 수 있어요',
  ];

  // int idx = -1;

  final List<IconData> _iconTypes = [
    Icons.directions_bus,
    FontAwesomeIcons.dog,
    FontAwesomeIcons.pencilAlt,
    FontAwesomeIcons.utensilSpoon,
    Icons.sports_baseball,
    FontAwesomeIcons.question,
  ];

  final ClientRole? _role = ClientRole.Broadcaster;

  FirebaseAuth auth = FirebaseAuth.instance;

  User? get userProfile => auth.currentUser;
  User? currentUser;

  var firebaseUser = FirebaseAuth.instance.currentUser;
  final _channelController = TextEditingController();

  final TextEditingController _categoryController = TextEditingController();

  @override
  void dispose() {
    _channelController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final _authController = Get.find<AuthController>();
    Get.put(ButtonController());




    print("HOME is signed in: ${_authController.isSignedIn}");
    return Scaffold(
      appBar: AppBar(
        title: SvgPicture.asset(
          "assets/appBar.svg",
          height: 27.h,
        ),
        elevation: 0.0,
        centerTitle: false,
        backgroundColor: Color(0xffF8F9FA),
        actions: <Widget>[
          IconButton(
            icon: Icon(
              Icons.notifications_rounded,
              color: Colors.grey[400],
            ),
            onPressed: () {},
          ),
          IconButton(
            icon: Icon(
              Icons.settings,
              color: Colors.grey[400],
            ),
            onPressed: () {},
          ),
        ],
      ),
      body: Container(
        color: Color(0xffF8F9FA),
        child: Stack(children: [


    Center(
            child: Column (
              children:  [

                SizedBox(
                  height: 40.h,
                ),

                Text(
                  "세상의 모든 인재들이 모인 공간",
                  style: TextStyle(
                      fontSize: 20.sp,
                      fontWeight: FontWeight.bold,
                      color: Color(0xff343A40)),
                ),
                SizedBox(
                  height: 20.h,
                ),
                Text(
                  "참여 중인 답변자",
                  style: TextStyle(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.bold,
                      color: Color(0xff343A40)),
                ),


                Text(
                  "234,455",
                  style: TextStyle(
                    fontSize: 20.sp,
                    fontWeight: FontWeight.bold,
                    color: Color(0xffF57F17),
                  ),
                ),
              ],
            ),
          ),
          Center(
            child: Column(
              children: [
                SizedBox(
                  height: 420.h,
                ),
                Icon(Icons.arrow_drop_up, color: Color(0xffADB5BD)),
                Icon(Icons.arrow_drop_up, color: Color(0xffADB5BD)),
                Text(
                  '고민말고 도움을 요청하세요',
                  style: TextStyle(color: Color(0xff868E96)),
                  // style: bodyhighlightStyle(
                  //   color: Colors.black,
                  //   fontsize: 12,
                  //   height: 1.5,
                  // ),
                ),
                SizedBox(
                  height: 30.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      height: 59.h,
                      width: 151.w,
                      child: ElevatedButton(
                        onPressed: () {
                          Get.to(guidePage());
                        },
                        child: Text(
                          "사용설명서",
                          style: TextStyle(color: Color(0xff6F7378)),
                        ),
                        style: ElevatedButton.styleFrom(
                          primary: Color(0xffFFFFFF),
                          padding: EdgeInsets.all(20),
                          shape: new RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(20.0),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 15.w),
                    SizedBox(
                      height: 59.h,
                      width: 151.w,
                      child: ElevatedButton(
                        onPressed: () {},
                        child: Text(
                          "랭킹",
                          style: TextStyle(color: Color(0xff6F7378)),
                        ),
                        style: ElevatedButton.styleFrom(
                          primary: Color(0xffFFFFFF),
                          padding: EdgeInsets.all(20),
                          shape: new RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(20.0),
                          ),
                        ),
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),

          GetBuilder<ButtonController>(
              init: ButtonController(),
              builder: (_) {
                return _.dark
                    ? Container()
                    : Stack(
                        children: [
                          GestureDetector(
                            onTap: () {
                              // Get.find<ButtonController>().controllerclose();
                              setState(() {
                                _.changetrue();

                                Navigator.pushAndRemoveUntil(
                                  context,
                                  FadeRoute(
                                    page: Navigation(),
                                  ),
                                      (route) => false,
                                );
                              });

                            },
                            child: Container(
                              width: MediaQuery.of(context).size.width,
                              height: MediaQuery.of(context).size.height,
                              color: Colors.black.withOpacity(0.8),
                            ),
                          ),
                          Column(
                            children: [
                              SizedBox(
                                height: 400.h,
                              ),
                              if (Get.find<ButtonController>().idx != 5) Column(
                                      children: [
                                        Center(
                                            child: Icon(
                                                _iconTypes[
                                                    Get.find<ButtonController>()
                                                        .idx],
                                                size: 32.sp,
                                                color: Color(0xffF9A825))),
                                        SizedBox(
                                          height: 12.h,
                                        ),
                                        Center(
                                          child: Text(
                                            _titleList[
                                                Get.find<ButtonController>()
                                                    .idx],
                                            style: TextStyle(
                                                fontSize: 18.sp,
                                                color: Colors.white),
                                          ),
                                        ),
                                        Center(
                                          child: Text(
                                            _textList[0],
                                            //_textList[0],
                                            style: TextStyle(
                                                fontSize: 12.sp,
                                                color: Colors.white,
                                                height: 2.1.h),
                                          ),
                                        ),
                                        SizedBox(
                                          height: 12.h,
                                        ),

                                        SizedBox(
                                          height: 50.h,
                                          width: 151.w,
                                          child: ElevatedButton(
                                            onPressed: () async {
                                              setState(() {
                                                FirebaseFirestore.instance
                                                    .collection("videoCall")
                                                    .doc(firebaseUser!.uid)
                                                    .set({
                                                  "count": 1,
                                                  "timeRegister": DateTime.now()
                                                      .millisecondsSinceEpoch
                                                      .toString(),
                                                  "uid": firebaseUser!.uid,
                                                  "name":
                                                      firebaseUser!.displayName,
                                                  "category": _titleList[
                                                      Get.find<
                                                              ButtonController>()
                                                          .idx],
                                                  "index" : Get.find<
                                                      ButtonController>()
                                                      .idx,
                                                  "subcategory":_categoryController.text.trim()
                                                });
                                              });

                                              await Get.to(() => SubCategory(

                                                    //  role: _role,
                                                  ));
                                            },
                                            child: Text(
                                              "연결하기",
                                              style: TextStyle(
                                                  color: Color(0xff6F7378)),
                                            ),
                                            style: ElevatedButton.styleFrom(
                                              primary: Color(0xffFFFFFF),
                                              shape: new RoundedRectangleBorder(
                                                borderRadius:
                                                    new BorderRadius.circular(
                                                        20.0),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ) else Container()
                            ],
                          )
                        ],
                      );
              }),


    // StreamBuilder<QuerySnapshot>(
    // stream: _usersStream,
    // builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
    // if (snapshot.hasError) {
    // return Scaffold(body: const Text('Firebase Data has not received'));
    // }
    // if (snapshot.connectionState == ConnectionState.waiting) {
    // return const Scaffold(body:Center(child: CircularProgressIndicator()));
    // }}),



          Column(
            children: [
              SizedBox(
                height: 160.h,
              ),
              RadialMenu(
                children: [
                  RadialButton(
                      icon: Icon(Icons.directions_bus,
                          size: 32.sp, color: pressed1 ? Color(0xffF9A825):Color(0xff7B7B7B)),
                      buttonColor: Color(0xffF8F9FA),
                      style: pressed1
                          ? ButtonStyle() : ButtonStyle(),
                      onPress: () {
                        setState(() {
                          Get.find<ButtonController>().idx = 0;
                          pressed1= !pressed1;
                          pressed2=false;
                          pressed3=false;
                          pressed4=false;
                          pressed5=false;
                          //pressed = !pressed;
                        });
                      }),
                  RadialButton(
                      icon: Icon(FontAwesomeIcons.dog,
                          size: 28.sp, color: pressed2 ? Color(0xffF9A825):Color(0xff7B7B7B)),
                      buttonColor: Color(0xffF8F9FA),
                      style: pressed2 ? ButtonStyle(backgroundColor: MaterialStateProperty.all<Color>(AppColors.primaryColor),) : const ButtonStyle(),
                      onPress: () {
                        setState(() {
                          Get.find<ButtonController>().idx = 1;
                            pressed2= !pressed2;
                          pressed1=false;
                          pressed3=false;
                          pressed4=false;
                          pressed5=false;
                        });
                      }),
                  RadialButton(
                      icon: Icon(FontAwesomeIcons.pencilAlt,
                          size: 28.sp, color: pressed3 ? Color(0xffF9A825):Color(0xff7B7B7B)),
                      buttonColor: Color(0xffF8F9FA),
                      style: pressed3 ? ButtonStyle() : ButtonStyle(),
                      onPress: () {
                        setState(() {
                          Get.find<ButtonController>().idx = 2;
                          pressed3= !pressed3;
                          pressed1=false;
                          pressed2=false;
                          pressed4=false;
                          pressed5=false;
                        });
                      }),
                  RadialButton(
                      icon: Icon(FontAwesomeIcons.utensilSpoon,
                          size: 28.sp,color: pressed4 ? Color(0xffF9A825):Color(0xff7B7B7B)),
                      buttonColor: Color(0xffF8F9FA),
                      style: pressed4 ? ButtonStyle() : ButtonStyle(),
                      onPress: () {
                        setState(() {
                          Get.find<ButtonController>().idx = 3;
                          pressed4= !pressed4;
                          pressed1=false;
                          pressed3=false;
                          pressed2=false;
                          pressed5=false;
                        });
                      }),
                  RadialButton(
                      icon: Icon(Icons.sports_baseball,
                          size: 30.sp, color: pressed5 ? Color(0xffF9A825):Color(0xff7B7B7B)),
                      buttonColor: Color(0xffF8F9FA),
                      style: pressed5 ? ButtonStyle() : ButtonStyle(),
                      onPress: () {
                        setState(() {
                          Get.find<ButtonController>().idx = 4;
                          pressed5= !pressed5;
                          pressed1=false;
                          pressed3=false;
                          pressed4=false;
                          pressed2=false;
                        });
                      }),
                ],
              ),
            ],
          ),
        ]),
      ),
        );}

 //
 //
 // @override
 // Widget UserStream(BuildContext context){
 //    return StreamBuilder<QuerySnapshot>(
 //        stream: _usersStream,
 //        builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
 //          if (snapshot.hasError) {
 //            return Scaffold(body: const Text('Firebase Data has not received'));
 //          }
 //          if (snapshot.connectionState == ConnectionState.waiting) {
 //            return const Scaffold(body:Center(child: CircularProgressIndicator()));
 //          }});
 // }
  Future<void> _handleCameraAndMic(Permission permission) async {
    final status = await permission.request();
    print(status);
  }
  Stream<QuerySnapshot> _usersStream =
  FirebaseFirestore.instance.collection('users').snapshots();

  // Future<Widget> UserStream(context) async {
  //   return StreamBuilder<QuerySnapshot>(
  //       stream: _usersStream,
  //       builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
  //         if (snapshot.hasError) {
  //           return const Text('Firebase Data has not received');
  //         }
  //         if (snapshot.connectionState == ConnectionState.waiting) {
  //           return const Center(child: CircularProgressIndicator());
  //         }});}

}

class FadeRoute extends PageRouteBuilder {
  final Widget page;
  FadeRoute({required this.page})
      : super(
    pageBuilder: (
        BuildContext context,
        Animation<double> animation,
        Animation<double> secondaryAnimation,
        ) =>
    page,
    transitionsBuilder: (
        BuildContext context,
        Animation<double> animation,
        Animation<double> secondaryAnimation,
        Widget child,
        ) =>
        FadeTransition(
          opacity: animation,
          child: child,
        ),
  );
}
