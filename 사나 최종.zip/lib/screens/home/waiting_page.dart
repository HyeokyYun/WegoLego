
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter/material.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';

// ignore: camel_case_types
class WaitingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Center(
          child: Padding(
            padding: EdgeInsets.all(20.0),
            child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Row(
                    children: [
                      SizedBox(width: ScreenUtil().setWidth(20)),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,

                        children: [

                          Text(
                            '남은 매칭시간',
                            style: TextStyle(
                                fontSize: ScreenUtil().setSp(14),
                                color: Color(0xFFF9A825)),
                          ),
                          Text(
                            '1:35',
                            style: TextStyle(
                                fontSize: ScreenUtil().setSp(14),
                                color: Color(0xFFF9A825)),
                          ),
                        ],),
                      SizedBox(width: ScreenUtil().setWidth(173)),
                      Column(children: [
                        Icon(Icons.directions_bus, size:32,color: Color(0xffADB5BD)),
                        Text(
                          '버스',
                          style: TextStyle(
                              fontSize: ScreenUtil().setSp(12),
                              color: Color(0xFF868E96)),
                        ),
                      ],)
                    ],
                  ),
                  SizedBox(height: ScreenUtil().setHeight(140)),

                  Container(
                    height: ScreenUtil().setHeight(91.04),
                    width: ScreenUtil().setWidth(63),
                    child: SvgPicture.asset(
                      'assets/liveQ_logo.svg',
                    ),
                  ),
                  SizedBox(height: ScreenUtil().setHeight(30)),
                  Icon(Icons.circle,size:  ScreenUtil().setHeight(8), color: Color(0xffFABF8B)),
                  SizedBox(height: ScreenUtil().setHeight(16)),
                  Icon(Icons.circle,size:  ScreenUtil().setHeight(8), color: Color(0xffF79F51)),
                  SizedBox(height: ScreenUtil().setHeight(16)),
                  Icon(Icons.circle,size:  ScreenUtil().setHeight(8), color: Color(0xffF57F17)),
                  Column(children: [Column(children: [


                    SizedBox(height: ScreenUtil().setHeight(18)),
                    Text(
                      '답변자 매칭 중이에요',
                      style: TextStyle(
                          fontSize: ScreenUtil().setSp(18),
                          color: Color(0xFF212529)),
                    ),
                    SizedBox(height: ScreenUtil().setHeight(16)),
                    Text(
                      '매칭이 완료되면 실시간 화면',
                      style: TextStyle(
                          fontSize: ScreenUtil().setSp(14),
                          color: Color(0xFF212529)),
                    ),
                    SizedBox(height: ScreenUtil().setHeight(1.3)),
                    Text(
                      '공유를 통해 질문을 할 수 있어요',
                      style: TextStyle(
                          fontSize: ScreenUtil().setSp(14),
                          color: Color(0xFF212529)),
                    ),
                  ]),



                    SizedBox(height: ScreenUtil().setHeight(144)),
                    SizedBox(
                      height: ScreenUtil().setHeight(49),
                      width: ScreenUtil().setHeight(287),
                      child: ElevatedButton(
                        onPressed: () {
                          // Get.to(emailLoginPage());
                          // Navigator.push(
                          //   context,
                          //   MaterialPageRoute(builder: (context) => emailLoginPage()),
                          // );
                        },
                        child: Text(
                          '매칭 취소하기',
                          style: TextStyle(fontSize: ScreenUtil().setSp(14),color: Colors.black),
                        ),
                        style: ElevatedButton.styleFrom(
                          primary: const Color(0xffE9ECEF),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(33),
                          ),
                        ),
                      ),
                    ),

                    //SizedBox(height: ScreenUtil().setHeight(50)),
                  ],
                  ),
                ] ),
          ), // This trailing comma makes auto-formatting nicer for build methods.
        ));
  }
}
