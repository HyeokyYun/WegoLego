import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:livq/screens/my_page/my_setting_page.dart';
import 'package:livq/screens/my_page/sub_pages/1:1_question.dart';
import 'package:livq/screens/my_page/sub_pages/individual_information.dart';
import 'package:livq/screens/my_page/sub_pages/instruction_manual.dart';
import 'package:livq/screens/my_page/sub_pages/statechange.dart';
import 'package:livq/screens/my_page/sub_pages/terms_and_conditions.dart';
import 'package:livq/screens/root.dart';
import 'package:livq/theme/colors.dart';
//import 'package:livq/screens/my_page/myId.dart';
class MyPage extends StatefulWidget {
  const MyPage({Key? key}) : super(key: key);

  @override
  _MyPageState createState() => _MyPageState();
}

class _MyPageState extends State<MyPage> {
  FirebaseAuth auth = FirebaseAuth.instance;
  User? currentUser;
  var firebaseUser = FirebaseAuth.instance.currentUser;
  @override
  Widget build(BuildContext context) {
    Stream<DocumentSnapshot> _usersStream = FirebaseFirestore.instance
        .collection('users')
        .doc(firebaseUser!.uid)
        .snapshots();

    return StreamBuilder<DocumentSnapshot>(
        stream: _usersStream,
        builder:
            (BuildContext context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.hasError) {
            Get.snackbar('Error occurred!', "Can't read your user data",
                snackPosition: SnackPosition.BOTTOM,
                backgroundColor: Colors.green,
                colorText: Colors.white);
            Get.offAll(Root());
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          final getdata = snapshot.data;
          Stream<DocumentSnapshot> _thankStream = FirebaseFirestore.instance
              .collection('users')
              .doc(firebaseUser!.uid)
              .collection('thankLetter')
              .doc(firebaseUser!.uid)
              .snapshots();

          return StreamBuilder<DocumentSnapshot>(
            stream: _thankStream,
            builder: (BuildContext context,
                AsyncSnapshot<DocumentSnapshot> subsnapshot) {
              final getsubdata = subsnapshot.data;
              if (subsnapshot.hasError) {
                Get.snackbar('Error occurred!', "Can't read your user data",
                    snackPosition: SnackPosition.BOTTOM,
                    backgroundColor: Colors.green,
                    colorText: Colors.white);
                Get.offAll(Root());
              }
              if (subsnapshot.connectionState == ConnectionState.waiting) {
                // return splashWidget();
                return myPageWidget(context, "위고레고", 0, 0, 0);
              }
              return myPageWidget(
                  context,
                  getdata!["name"],
                  getsubdata!['thankLetter'].length,
                  getdata["ask"],
                  getdata["help"]);
            },
          );
        });
  }

  Widget myPageWidget(
      BuildContext context,
      // bool loading,
      String name,
      int getHeart,
      int helpCount,
      int askCount,
      ) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: Text(
            "마이 페이지",
            style: TextStyle(color: Colors.black),
          ),
          elevation: 0.0,
          backgroundColor: Colors.white,
          centerTitle: true,
          actions: [
            IconButton(
              onPressed: () {
                Get.to(mySettingPage());
              },
              icon: Icon(
                Icons.settings_sharp,
                color: Colors.black,
              ),
            )
          ],
        ),
        body: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.fromLTRB(28, 0, 28, 0),
            alignment: Alignment.topCenter,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(
                  height: 50.h,
                ),
                ClipRRect(
                  borderRadius: BorderRadius.circular(57),
                  child: SvgPicture.asset(
                    "assets/profile.svg",
                    height: 114.h,
                    width: 114.w,
                    fit: BoxFit.fill,
                  ),
                ),
                SizedBox(
                  height: 13.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  // crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      width: 8.w,
                      height: 8.h,
                      decoration: BoxDecoration(
                        color: Color(0xFFFBC02D),
                        borderRadius: BorderRadius.all(
                          Radius.circular(4.0),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 4,
                    ),
                    Text(
                      name,
                      style: TextStyle(
                        color: Colors.purple[800],
                        fontSize: 18.sp,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Text(
                      '님',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 18.sp,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                Text(
                  '오늘도 행복하세요!',
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 18.sp,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(
                  height: 40.h,
                ),
                Container(
                  height: 74.h,
                  decoration: BoxDecoration(
                    color: Color(0xFFF5F3FF),
                    borderRadius: BorderRadius.all(
                      Radius.circular(12),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 100.w,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              height: 17.h,
                              child: SvgPicture.asset(
                                "assets/heartIcon.svg",
                              ),
                            ),
                            SizedBox(
                              height: 13.h,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "받은 하트",
                                  style: TextStyle(
                                    fontSize: 12.sp,
                                    color: Colors.grey[700],
                                  ),
                                ),
                                SizedBox(
                                  width: 2.w,
                                ),
                                Column(
                                  children: [
                                    Text(
                                      "$getHeart",
                                      style: TextStyle(
                                        fontSize: 9.sp,
                                        color: Color(0xFFF57F17),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 5.h,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: 100.w,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              height: 19.h,
                              child: SvgPicture.asset(
                                "assets/answerIcon.svg",
                              ),
                            ),
                            SizedBox(
                              height: 13.h,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "응답 횟수",
                                  style: TextStyle(
                                    fontSize: 12.sp,
                                    color: Colors.grey[700],
                                  ),
                                ),
                                SizedBox(
                                  width: 2.w,
                                ),
                                Column(
                                  children: [
                                    Text(
                                      "$askCount",
                                      style: TextStyle(
                                          fontSize: 9.sp,
                                          color: Color(0xFFF57F17)),
                                    ),
                                    SizedBox(
                                      height: 5.h,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: 100.w,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              height: 18.h,
                              child: SvgPicture.asset(
                                "assets/questionIcon.svg",
                              ),
                            ),
                            SizedBox(
                              height: 13.h,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "질문 횟수",
                                  style: TextStyle(
                                    fontSize: 12.sp,
                                    color: Colors.grey[700],
                                  ),
                                ),
                                SizedBox(
                                  width: 2.w,
                                ),
                                Column(
                                  children: [
                                    Text(
                                      "$helpCount",
                                      style: TextStyle(
                                          fontSize: 9.sp,
                                          color: Color(0xFFF57F17)),
                                    ),
                                    SizedBox(
                                      height: 5.h,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 20.h,
                ),
                Column(
                  children: [
                    Container(
                      height: ScreenUtil().setHeight(450),
                      child: ListView.builder(
                        padding: const EdgeInsets.fromLTRB(0, 8, 0, 0),
                        itemCount: 6,
                        itemBuilder: (BuildContext context, int index) {
                          return _buildListView(context, index);
                        },
                      ),
                    ),
                    SizedBox(
                      height: 100.h,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ));
  }
}

Widget _buildListView(BuildContext context, int index) {
  final List<String> _list = [
    '계정 / 정보 관리',
    '1:1 문의',
    '내가 쓴 게시물 모아보기',
    '활동 상태 변경하기',
    '이용약관',
    '앱버전 정보',
  ];

  return Container(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ListTile(
          // leading: Text(_list[index]),
          title: Text(
            _list[index],
            style: TextStyle(color: AppColors.grey[900], fontSize: 14.sp),
            //style: body14Style(),
          ),
          trailing: index != 5
              ? Icon(
            Icons.arrow_forward_ios,
            size: 18.sp,
            color: Color(0xffADB5BD),
          )
              : Text("0.2.4",
              style: TextStyle(color: Color(0xffADB5BD), fontSize: 14.sp)),

          onTap: () async {
// begin of all IF statements
            if (index == 0) {
              await Get.to(() => StateChange());
            }
            if (index == 1) {
              await Get.to(() => Question());
            }
            if (index == 2) {
              await Get.to(() => Instruction());
            }
            if (index == 3) {
              await Get.to(() => Information());
            }
            if (index == 4) {
              await Get.to(() => Terms());
            }
            if (index == 5) {}
// end of all If statements
          },
        ),
        Divider(
          color: AppColors.grey[400],
          // thickness: 1.0,
        ),
      ],
    ),
  );
}